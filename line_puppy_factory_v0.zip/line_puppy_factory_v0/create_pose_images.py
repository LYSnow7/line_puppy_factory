#!/usr/bin/env python3
"""
创建简单的姿势图片用于演示
"""

from PIL import Image, ImageDraw
import os

def create_pose_image(pose_name, description):
    """创建一个简单的姿势图片"""
    width, height = 400, 400
    image = Image.new('RGB', (width, height), 'white')
    draw = ImageDraw.Draw(image)
    
    # 根据不同姿势绘制不同的简单线条图
    if pose_name == "lying_flat":
        # 躺平的小狗
        # 头部
        draw.ellipse([150, 180, 250, 220], outline='black', width=3)
        # 身体（横向椭圆）
        draw.ellipse([100, 200, 300, 240], outline='black', width=3)
        # 腿（短线）
        draw.line([120, 240, 120, 260], fill='black', width=3)
        draw.line([160, 240, 160, 260], fill='black', width=3)
        draw.line([240, 240, 240, 260], fill='black', width=3)
        draw.line([280, 240, 280, 260], fill='black', width=3)
        # 尾巴
        draw.line([300, 220, 330, 200], fill='black', width=3)
        
    elif pose_name == "jumping_happy":
        # 跳跃的小狗
        # 头部
        draw.ellipse([180, 100, 220, 140], outline='black', width=3)
        # 身体
        draw.ellipse([170, 140, 230, 200], outline='black', width=3)
        # 腿（向外伸展）
        draw.line([160, 180, 140, 220], fill='black', width=3)
        draw.line([180, 180, 160, 220], fill='black', width=3)
        draw.line([220, 180, 240, 220], fill='black', width=3)
        draw.line([240, 180, 260, 220], fill='black', width=3)
        # 尾巴（向上）
        draw.line([230, 150, 250, 120], fill='black', width=3)
        
    elif pose_name == "sitting_sad":
        # 坐着难过的小狗
        # 头部（稍微低垂）
        draw.ellipse([180, 120, 220, 160], outline='black', width=3)
        # 身体
        draw.ellipse([170, 160, 230, 220], outline='black', width=3)
        # 前腿
        draw.line([180, 220, 180, 260], fill='black', width=3)
        draw.line([220, 220, 220, 260], fill='black', width=3)
        # 后腿（坐姿）
        draw.line([170, 200, 150, 240], fill='black', width=3)
        draw.line([230, 200, 250, 240], fill='black', width=3)
        # 尾巴（下垂）
        draw.line([230, 180, 250, 200], fill='black', width=3)
        
    elif pose_name == "waving_hello":
        # 挥手打招呼的小狗
        # 头部
        draw.ellipse([180, 120, 220, 160], outline='black', width=3)
        # 身体
        draw.ellipse([170, 160, 230, 220], outline='black', width=3)
        # 一只前腿举起
        draw.line([180, 180, 160, 140], fill='black', width=3)
        # 另一只前腿
        draw.line([220, 220, 220, 260], fill='black', width=3)
        # 后腿
        draw.line([170, 200, 150, 240], fill='black', width=3)
        draw.line([230, 200, 250, 240], fill='black', width=3)
        # 尾巴（摇摆）
        draw.arc([230, 160, 270, 200], start=270, end=90, fill='black', width=3)
        
    elif pose_name == "thinking":
        # 思考的小狗
        # 头部
        draw.ellipse([180, 120, 220, 160], outline='black', width=3)
        # 身体
        draw.ellipse([170, 160, 230, 220], outline='black', width=3)
        # 一只前腿抬起到头部（思考姿势）
        draw.line([180, 180, 170, 150], fill='black', width=3)
        # 另一只前腿
        draw.line([220, 220, 220, 260], fill='black', width=3)
        # 后腿
        draw.line([170, 200, 150, 240], fill='black', width=3)
        draw.line([230, 200, 250, 240], fill='black', width=3)
        # 思考泡泡
        draw.ellipse([240, 80, 260, 100], outline='black', width=2)
        draw.ellipse([250, 100, 265, 115], outline='black', width=2)
        draw.ellipse([260, 115, 270, 125], outline='black', width=2)
        
    elif pose_name == "crying":
        # 哭泣的小狗
        # 头部
        draw.ellipse([180, 120, 220, 160], outline='black', width=3)
        # 身体
        draw.ellipse([170, 160, 230, 220], outline='black', width=3)
        # 前腿
        draw.line([180, 220, 180, 260], fill='black', width=3)
        draw.line([220, 220, 220, 260], fill='black', width=3)
        # 后腿
        draw.line([170, 200, 150, 240], fill='black', width=3)
        draw.line([230, 200, 250, 240], fill='black', width=3)
        # 眼泪
        draw.line([185, 140, 185, 155], fill='blue', width=2)
        draw.line([215, 140, 215, 155], fill='blue', width=2)
        # 尾巴（下垂）
        draw.line([230, 180, 250, 210], fill='black', width=3)
    
    return image

def main():
    # 创建目录
    os.makedirs("data/controlnet_poses", exist_ok=True)
    
    # 定义姿势
    poses = {
        "lying_flat": "躺平姿势",
        "jumping_happy": "开心跳跃",
        "sitting_sad": "坐着难过",
        "waving_hello": "挥手打招呼",
        "thinking": "思考姿势",
        "crying": "哭泣姿势"
    }
    
    # 创建每个姿势的图片
    for pose_name, description in poses.items():
        print(f"创建姿势图片: {pose_name} - {description}")
        image = create_pose_image(pose_name, description)
        image.save(f"data/controlnet_poses/{pose_name}.png")
    
    print("所有姿势图片创建完成！")

if __name__ == "__main__":
    main()
