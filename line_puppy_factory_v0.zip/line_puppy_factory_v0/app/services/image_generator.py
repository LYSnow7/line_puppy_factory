# app/services/image_generator.py
import requests
import os
import base64
from dotenv import load_dotenv

load_dotenv()

# --- 这里是修正后的代码 ---
# 确保 STABLE_DIFFUSION_API_URL 的赋值是独立的一行
STABLE_DIFFUSION_API_URL = os.getenv("STABLE_DIFFUSION_API_URL")

# 确保 async def 是新起的一行，并且函数名没有空格
async def generate_image_from_prompt(prompt: str, pose_image_path: str) -> bytes:
    """
    Uses a real Stable Diffusion API with ControlNet to generate an image.
    Returns the image's binary data (bytes).
    """
    print("--- Starting Real Image Generation ---")
    print(f"Prompt: {prompt}")
    print(f"Using Pose Image: {pose_image_path}")

    if not STABLE_DIFFUSION_API_URL:
        raise ValueError("STABLE_DIFFUSION_API_URL is not set in the .env file.")

    if not os.path.exists(pose_image_path):
        raise FileNotFoundError(f"Pose image not found: {pose_image_path}. Please add it to data/controlnet_poses/")

    # 1. Encode the pose image to base64
    with open(pose_image_path, 'rb') as f:
        encoded_pose_image = base64.b64encode(f.read()).decode('utf-8')

    # 2. Construct the API payload
    # The prompt already contains the LoRA trigger word from the llm_service
    # Now we add the <lora:model_name:weight> syntax
    final_prompt = f"{prompt}, <lora:xiantiaogou_style:1>"

    payload = {
        "prompt": final_prompt,
        "negative_prompt": "blurry, ugly, deformed, 3d, realistic, text, signature, watermark",
        "steps": 25,
        "cfg_scale": 7,
        "seed": -1,
        "sampler_name": "DPM++ 2M Karras",
        "alwayson_scripts": {
            "controlnet": {
                "args": [
                    {
                        "input_image": encoded_pose_image,
                        "module": "lineart",  # Using lineart for cleaner outlines
                        "model": "control_v11p_sd15_lineart [43d4be0d]", # Ensure you have this model
                        "weight": 1,
                        "pixel_perfect": True,
                        "control_mode": "Balanced"
                    }
                ]
            }
        }
    }

    # 3. Send the request to the API
    try:
        print("Sending request to Stable Diffusion API...")
        response = requests.post(url=STABLE_DIFFUSION_API_URL, json=payload, timeout=120) # 增加超时时间
        response.raise_for_status()  # Raise an exception for bad status codes

        r = response.json()
        image_b64 = r['images'][0]

        print("--- Image Generation Successful ---")
        return base64.b64decode(image_b64)

    except requests.exceptions.RequestException as e:
        print(f"Error calling Stable Diffusion API: {e}")
        # Consider how to handle this error in your app
        raise
