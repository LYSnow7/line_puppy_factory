# app/services/llm_service.py
import os
import json
import google.generativeai as genai
from dotenv import load_dotenv

# 重新加载环境变量以获取新的API key
load_dotenv(override=True)
GOOGLE_API_KEY = os.getenv("GEMINI_API_KEY")
print(f"使用API Key: {GOOGLE_API_KEY[:10]}..." if GOOGLE_API_KEY else "未找到API Key")
genai.configure(api_key=GOOGLE_API_KEY)
text_model = genai.GenerativeModel('gemini-1.5-flash-latest')

PROMPT_ENGINEER_SYSTEM_PROMPT = """
你是一位富有创意的AI绘画Prompt工程师，专注于“线条小狗”这个IP。你的任务是根据用户提供的情绪和一句话，创作一个高质量的Stable Diffusion绘画Prompt。
请遵循以下规则：
1.  核心风格：Prompt中必须包含 simple line art, white background, sticker style, minimalist 等核心风格词。
2.  创意发挥：将用户的情绪和文字转化为生动的画面描述。
3.  姿势关键词：从列表中建议一个姿势关键词: [lying_flat, jumping_happy, sitting_sad, waving_hello, thinking, crying]。
4.  输出格式：仅返回一个有效的JSON对象，包含两个键：positive_prompt 和 controlnet_pose_keyword。
"""

async def generate_creative_prompt(emotion: str, text: str) -> dict:
    import asyncio

    generation_config = genai.types.GenerationConfig(response_mime_type="application/json")
    full_prompt = f"{PROMPT_ENGINEER_SYSTEM_PROMPT}\n\n用户输入:\n- 情绪: \"{emotion}\"\n- 文字: \"{text}\"\n\n现在请生成JSON输出。"

    try:
        print("正在调用Gemini API生成Prompt...")

        # 添加超时机制，10秒后如果没有响应就使用备用逻辑
        def call_gemini():
            return text_model.generate_content(full_prompt, generation_config=generation_config)

        try:
            response = await asyncio.wait_for(
                asyncio.to_thread(call_gemini),
                timeout=10.0
            )
            print(f"Gemini API响应: {response.text}")
            result = json.loads(response.text)
            print("成功从Gemini API获取Prompt。")
            return result
        except asyncio.TimeoutError:
            print("Gemini API调用超时，使用备用逻辑...")
            return create_fallback_prompt(emotion, text)

    except json.JSONDecodeError as e:
        print(f"JSON解析错误: {e}")
        print(f"原始响应: {response.text if 'response' in locals() else 'No response'}")
        return create_fallback_prompt(emotion, text)
    except Exception as e:
        print(f"调用Gemini API时出错: {e}")
        return create_fallback_prompt(emotion, text)

def create_fallback_prompt(emotion: str, text: str) -> dict:
    """创建一个备用的提示词，当API调用失败时使用"""

    # 情绪到姿势的映射
    emotion_mapping = {
        "开心": "jumping_happy",
        "难过": "sitting_sad",
        "生气": "sitting_sad",
        "生无可恋": "lying_flat",
        "思考": "thinking",
        "庆祝": "jumping_happy"
    }

    # 情绪到描述词的映射
    emotion_descriptions = {
        "开心": ["cheerful", "joyful", "excited", "happy", "bouncing", "tail wagging"],
        "难过": ["sad", "melancholy", "droopy ears", "downcast", "sitting quietly", "looking down"],
        "生气": ["angry", "grumpy", "frowning", "stern", "puffed up", "crossed arms"],
        "生无可恋": ["exhausted", "lying flat", "defeated", "tired", "sprawled out", "giving up"],
        "思考": ["thoughtful", "pondering", "curious", "head tilted", "paw on chin", "contemplating"],
        "庆祝": ["celebrating", "party hat", "confetti", "dancing", "jumping with joy", "festive"]
    }

    # 根据文字内容添加额外描述
    text_keywords = {
        "工作": "office setting, computer nearby",
        "加班": "tired, coffee cup, late night",
        "周末": "relaxed, casual, happy",
        "吃饭": "food bowl, kitchen setting",
        "睡觉": "cozy, pillow, blanket",
        "运动": "energetic, sporty, active",
        "学习": "books, studious, focused",
        "朋友": "social, friendly, warm",
        "家": "home setting, comfortable, cozy"
    }

    pose_keyword = emotion_mapping.get(emotion, "sitting_sad")
    emotion_desc = emotion_descriptions.get(emotion, ["cute"])

    # 选择2-3个情绪描述词
    import random
    selected_emotions = random.sample(emotion_desc, min(3, len(emotion_desc)))

    # 检查文字中是否包含特定关键词
    extra_desc = ""
    for keyword, description in text_keywords.items():
        if keyword in text:
            extra_desc = f", {description}"
            break

    # 构建更丰富的提示词
    prompt = f"simple line art drawing of an adorable puppy, {', '.join(selected_emotions)}, expressing '{text}', clean black lines on white background, minimalist cartoon style, sticker design, kawaii aesthetic{extra_desc}, perfect for emoji or sticker use"

    return {
        "positive_prompt": prompt,
        "controlnet_pose_keyword": pose_keyword
    }