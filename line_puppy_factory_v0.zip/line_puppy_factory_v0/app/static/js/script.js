document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('emoji-form');
    const resultContainer = document.getElementById('result-container');
    const resultImage = document.getElementById('result-image');
    const spinner = document.getElementById('loading-spinner');
    const generateBtn = document.getElementById('generate-btn');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // 显示加载动画并禁用按钮
        spinner.classList.remove('hidden');
        resultContainer.classList.remove('hidden');
        resultImage.classList.add('hidden');
        generateBtn.disabled = true;
        generateBtn.textContent = '生成中...';

        const formData = new FormData(form);

        try {
            const response = await fetch('/generate', {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`生成失败: ${errorText}`);
            }

            const imageBlob = await response.blob();
            const imageUrl = URL.createObjectURL(imageBlob);

            resultImage.src = imageUrl;
            resultImage.classList.remove('hidden');

        } catch (error) {
            console.error('错误:', error);
            alert(error.message);
        } finally {
            // 隐藏加载动画并恢复按钮
            spinner.classList.add('hidden');
            generateBtn.disabled = false;
            generateBtn.textContent = '立刻生成';
        }
    });
});