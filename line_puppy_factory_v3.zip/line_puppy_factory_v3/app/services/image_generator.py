# app/services/image_generator.py
import os
import base64
import requests # Make sure you have 'requests' installed: pip install requests

# --- 真实逻辑示例 (以Automatic1111 API为例) ---
# 您需要将这个URL替换为您自己运行的Stable Diffusion服务的地址
API_URL = os.getenv("STABLE_DIFFUSION_API_URL", "http://127.0.0.1:7860/sdapi/v1/txt2img")

async def generate_image_from_prompt(prompt: str, pose_image_path: str) -> bytes:
    """
    使用带ControlNet和LoRA的Stable Diffusion API生成图片。
    """
    print("--- 开始真实图像生成 ---")
    print(f"使用的Prompt: {prompt}")
    print(f"使用的姿势图片: {pose_image_path}")

    if not os.path.exists(pose_image_path):
        raise FileNotFoundError(f"姿势图片未找到: {pose_image_path}。请将其添加到 data/controlnet_poses/ 目录。")

    # 1. 将姿势图片进行Base64编码
    with open(pose_image_path, 'rb') as f:
        encoded_pose_image = base64.b64encode(f.read()).decode('utf-8')

    # 2. 构建发送到API的JSON负载 (Payload)
    # 这是最关键的一步
    payload = {
        "prompt": prompt, # Prompt中应包含LoRA触发词, 例如 <lora:xiantiaogou_style:1>
        "negative_prompt": "blurry, ugly, deformed, 3d, realistic, text, signature, watermark",
        "steps": 25,
        "cfg_scale": 7,
        "width": 512,
        "height": 512,
        "sampler_name": "DPM++ 2M Karras",
        "alwayson_scripts": {
            "controlnet": {
                "args": [
                    {
                        "input_image": encoded_pose_image,
                        "module": "canny", # 或者 lineart, 取决于您的ControlNet模型
                        "model": "control_v11p_sd15_canny [d14c016b]", # 替换为您自己的ControlNet模型名
                        "weight": 1.0,
                        "resize_mode": "Crop and Resize",
                        "control_mode": "Balanced"
                    }
                ]
            }
        }
    }

    # 3. 发送API请求
    try:
        response = requests.post(url=API_URL, json=payload)
        response.raise_for_status() # 如果请求失败则会抛出异常

        r = response.json()
        # 4. 解码返回的图片数据
        image_b64 = r['images'][0]
        image_bytes = base64.b64decode(image_b64)
        
        print("--- 图像生成成功 ---")
        return image_bytes

    except requests.exceptions.RequestException as e:
        print(f"调用Stable Diffusion API时出错: {e}")
        # 在这里可以返回一张默认的错误图片
        raise ConnectionError(f"无法连接到Stable Diffusion服务: {e}")
    except KeyError:
        print(f"API返回的JSON格式不正确: {response.text}")
        raise ValueError("API返回数据格式错误")