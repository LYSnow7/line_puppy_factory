# app/main.py
import os
import base64
from fastapi import FastAPI, Request, Form
# 确保导入了 JSONResponse
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv

from app.services import llm_service, image_generator, post_processor

load_dotenv()

app = FastAPI()

app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    # 您可以根据您的地图微调这里的坐标
    locations = [
        {"name":"快乐海滩", "emotion":"开心", "style":"top:58%; left:50%;"},
        {"name":"忧伤山谷", "emotion":"难过", "style":"top:37%; left:58%;"},
        {"name":"愤怒火山", "emotion":"生气", "style":"top:41%; left:88%;"},
        {"name":"空虚废墟", "emotion":"生无可恋", "style":"top:45%; left:10%;"},
        {"name":"沉思森林", "emotion":"思考", "style":"top:80%; left:10%;"},
        {"name":"庆典广场", "emotion":"庆祝", "style":"top:85%; left:60%;"}
    ]
    return templates.TemplateResponse("index.html", {"request": request, "locations": locations})

# --- 核心修改在这里 ---
# 确保路由的返回类型是 JSONResponse
@app.post("/generate", response_class=JSONResponse)
async def generate_emoji(request: Request, emotion: str = Form(...), text: str = Form(...)):
    # 1. 从LLM服务获取创意Prompt和所有文本数据
    print(f"收到请求: 情绪='{emotion}', 文字='{text}'")
    llm_result = await llm_service.generate_creative_prompt(emotion, text)
    if not llm_result:
        return JSONResponse(content={"error": "从LLM获取创意内容失败。"}, status_code=500)

    positive_prompt = llm_result.get("positive_prompt")
    pose_keyword = llm_result.get("controlnet_pose_keyword")

    # 2. 找到对应的姿势图片并生成基础图片
    pose_image_path = f"data/controlnet_poses/{pose_keyword}.png"
    try:
        generated_image_bytes = await image_generator.generate_image_from_prompt(
            prompt=positive_prompt,
            pose_image_path=pose_image_path
        )
    except FileNotFoundError as e:
        return JSONResponse(content={"error": str(e)}, status_code=404)
    except Exception as e:
        return JSONResponse(content={"error": f"生成图片失败: {e}"}, status_code=500)

    # 3. 将用户原始文字添加到图片上 (这里可以根据您的需要决定是否添加)
    final_image_bytes = post_processor.add_text_to_image(generated_image_bytes, text)

    # 4. 将最终图片编码为Base64字符串
    image_base64 = base64.b64encode(final_image_bytes).decode('utf-8')

    # 5. 构建并返回一个包含图片和文本数据的JSON对象
    response_data = {
        "imageData": image_base64,
        "textData": {
            "locationName": llm_result.get("location_name", "未知地点"),
            "travelogueSnippet": llm_result.get("travelogue_snippet", "一段奇妙的旅行..."),
            "mapCoordinates": llm_result.get("map_coordinates", "N 0°0′ E 0°0′")
        }
    }
    
    # 确保最后返回的是这个JSON对象
    return JSONResponse(content=response_data)