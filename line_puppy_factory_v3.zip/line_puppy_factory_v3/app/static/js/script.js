document.addEventListener('DOMContentLoaded', () => {
    // --- 视图元素 ---
    const mainView = document.getElementById('main-view');
    const loadingView = document.getElementById('loading-view');
    const packageView = document.getElementById('package-view');
    const postcardView = document.getElementById('postcard-view');
    const atlasView = document.getElementById('atlas-view');

    // --- 主界面元素 ---
    const form = document.getElementById('emoji-form');
    const emotionInput = document.getElementById('emotion-input');
    const generateBtn = document.getElementById('generate-btn');
    const locations = document.querySelectorAll('.location-dot');

    // --- 明信片视图元素 ---
    const surprisePackage = document.getElementById('surprise-package');
    const postcardImage = document.getElementById('postcard-image');
    const postcardCoords = document.getElementById('postcard-coords');
    const postcardLocation = document.getElementById('postcard-location');
    const postcardLog = document.getElementById('postcard-log');
    const restartButton = document.getElementById('restart-button');

    // --- 旅行图鉴元素 ---
    const atlasButton = document.getElementById('atlas-button');
    const atlasCloseButton = document.getElementById('atlas-close-button');
    const atlasGrid = document.getElementById('atlas-grid');

    // --- 全局状态 ---
    let currentPostcardData = null;
    let lastActiveView = mainView; // 新增：记录上一个视图

    // --- 视图切换函数 ---
    const switchView = (viewToShow) => {
        // 在切换前，如果目标不是图鉴，就记录当前视图
        document.querySelectorAll('.view:not(.hidden)').forEach(activeView => {
            if (activeView.id !== 'atlas-view') {
                lastActiveView = activeView;
            }
        });
        
        [mainView, loadingView, packageView, postcardView, atlasView].forEach(view => {
            view.classList.toggle('hidden', view !== viewToShow);
        });
    };

    // --- 地图地点选择逻辑 ---
    locations.forEach(loc => {
        loc.addEventListener('click', () => {
            locations.forEach(l => l.classList.remove('selected'));
            loc.classList.add('selected');
            emotionInput.value = loc.dataset.emotion;
        });
    });

    // --- 表单提交逻辑 ---
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!emotionInput.value) {
            alert('请先在地图上选择一个目的地！');
            return;
        }

        switchView(loadingView);
        generateBtn.disabled = true;

        try {
            const response = await fetch('/generate', {
                method: 'POST',
                body: new FormData(form),
            });
            
            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || '未知错误');
            }
            
            currentPostcardData = result;
            
            const imageUrl = `data:image/png;base64,${result.imageData}`;
            postcardImage.src = imageUrl;
            savePostcardToAtlas(imageUrl);
            
            switchView(packageView);

        } catch (error) {
            console.error('生成失败:', error);
            alert(`生成失败: ${error.message}`);
            switchView(mainView);
        } finally {
            generateBtn.disabled = false;
        }
    });

    // --- 包裹点击逻辑 ---
    surprisePackage.addEventListener('click', () => {
        if (currentPostcardData && currentPostcardData.textData) {
            const { textData } = currentPostcardData;
            postcardLocation.textContent = textData.locationName;
            postcardLog.textContent = textData.travelogueSnippet;
            postcardCoords.textContent = textData.mapCoordinates;
        }

        surprisePackage.classList.add('package-opening');
        setTimeout(() => {
            switchView(postcardView);
            surprisePackage.classList.remove('package-opening');
        }, 500);
    });

    // --- 重新开始逻辑 ---
    restartButton.addEventListener('click', () => {
        form.reset();
        locations.forEach(l => l.classList.remove('selected'));
        emotionInput.value = '';
        currentPostcardData = null;
        switchView(mainView);
    });

    // --- 旅行图鉴逻辑 ---
    const getAtlasData = () => JSON.parse(localStorage.getItem('puppyAtlas')) || [];
    const saveAtlasData = (data) => localStorage.setItem('puppyAtlas', JSON.stringify(data));

    const savePostcardToAtlas = (base64Url) => {
        const atlasData = getAtlasData();
        atlasData.unshift(base64Url);
        saveAtlasData(atlasData);
    };

    const renderAtlas = () => {
        const atlasData = getAtlasData();
        atlasGrid.innerHTML = ''; 
        if (atlasData.length === 0) {
            const p = document.createElement('p');
            p.className = 'atlas-empty-message';
            p.textContent = '还没有任何旅行记录，快去创造你的第一张明信片吧！';
            atlasGrid.appendChild(p);
        } else {
            atlasData.forEach(url => {
                const img = document.createElement('img');
                img.src = url;
                img.alt = '收藏的明信片';
                atlasGrid.appendChild(img);
            });
        }
    };

    atlasButton.addEventListener('click', () => {
        renderAtlas();
        switchView(atlasView);
    });

    // 更新：关闭按钮逻辑
    atlasCloseButton.addEventListener('click', () => {
        switchView(lastActiveView); // 返回到上一个视图
    });
});