# app/services/llm_service.py
import os
import json
import google.generativeai as genai
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Configure the Gemini API
GOOGLE_API_KEY = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=GOOGLE_API_KEY)
text_model = genai.GenerativeModel('gemini-1.5-flash-latest')

# --- NEW: Updated System Prompt for Richer Content ---
# This new prompt instructs the AI to generate a more detailed package for the postcard.
PROMPT_ENGINEER_SYSTEM_PROMPT = """
你是一位富有创意的AI旅行规划师和艺术家，专注于“线条小狗”的奇幻之旅。
你的任务是根据用户的情绪和一句话，规划一次独特的旅行，并创作一张信息丰富的旅行明信片。

请严格遵循以下规则:
1.  **地点命名 (Location Naming)**: 基于用户情绪，创造一个富有诗意的地点名称，并附上它的英文翻译。格式为: 中文名 (English Name)。例如: 宁静湖泊 (Peaceful Lake)。
2.  **旅行日志 (Travelogue Snippet)**: 基于用户情绪和文字，将用户的简单输入扩写成一段2-3句话的、充满画面感和情感的第一人称旅行感言。
3.  **地图坐标 (Map Coordinates)**: 为该地点生成一个虚构但看起来真实的地理坐标。格式为: N XX°XX′ E XXX°XX′。
4.  **绘画提示 (Image Prompt)**: 创作一个高质量的 Stable Diffusion 绘画 Prompt。必须在Prompt的开头包含LoRA触发短语: `<lora:xiantiaogou_style:1>`。必须包含 `simple line art`, `white background`, `sticker style`, `minimalist` 等核心风格词。
5.  **姿势建议 (Pose Keyword)**: 从列表中建议一个最匹配的姿势关键词: [`lying_flat`, `jumping_happy`, `sitting_sad`, `waving_hello`, `thinking`, `crying`, `dancing_happy`, `peeking`, `angry`, `best_friends`, `crying_head_down`, `curled_up`, `dancing_happy`, `eating_poop`, `flirting`, `getting_strong`, `head_down_sad`, `looking_around`, `napping`, `picking_up`, `rose_in_mouth`, `running_happy`, `shaking_head_happy`, `shedding_tears`, `sleepy`, `surprised`, `working`]
]。
6.  **输出格式**: 仅返回一个有效的 JSON 对象，不得包含任何其他解释性文字。JSON 必须包含以下五个键: `location_name`, `travelogue_snippet`, `map_coordinates`, `positive_prompt`, 和 `controlnet_pose_keyword`。
"""

async def generate_creative_prompt(emotion: str, text: str) -> dict:
    """
    Generates a creative prompt package from the Gemini API based on user input.
    """
    generation_config = genai.types.GenerationConfig(response_mime_type="application/json")
    
    full_prompt = f"{PROMPT_ENGINEER_SYSTEM_PROMPT}\n\n用户输入:\n- 情绪：\"{emotion}\"\n- 文字：\"{text}\"\n\n现在请生成JSON输出。"
    
    try:
        print("正在调用Gemini API生成更丰富的Prompt...")
        response = await text_model.generate_content_async(full_prompt, generation_config=generation_config)
        
        result = json.loads(response.text)
        
        print("成功从Gemini API获取Prompt。")
        return result
        
    except Exception as e:
        print(f"调用Gemini API时出错：{e}")
        return None
