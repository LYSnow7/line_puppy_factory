# app/main.py
import os
import uuid  # 用于生成唯一文件名
import base64
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv
from supabase import create_client, Client  # 导入Supabase

# services
from app.services import llm_service, image_generator, post_processor

# --- Supabase 初始化 ---
load_dotenv()
supabase_url = os.getenv("SUPABASE_URL")
supabase_key = os.getenv("SUPABASE_SERVICE_KEY")
# 增加一个检查，确保环境变量已设置
if not supabase_url or not supabase_key:
    raise ValueError("Supabase URL和Key必须在.env文件中设置！")
supabase: Client = create_client(supabase_url, supabase_key)
# ---

app = FastAPI()

# --- 应用配置 ---
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")
# ---

# --- 根路由 ---
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    locations = [
        {"name":"快乐海滩", "emotion":"开心", "style":"top:58%; left:50%;"},
        {"name":"忧伤山谷", "emotion":"难过", "style":"top:37%; left:58%;"},
        {"name":"愤怒火山", "emotion":"生气", "style":"top:41%; left:88%;"},
        {"name":"空虚废墟", "emotion":"生无可恋", "style":"top:45%; left:10%;"},
        {"name":"沉思森林", "emotion":"思考", "style":"top:80%; left:10%;"},
        {"name":"庆典广场", "emotion":"庆祝", "style":"top:85%; left:60%;"}
    ]
    return templates.TemplateResponse("index.html", {"request": request, "locations": locations})
# ---

# ✅ 新增：获取所有明信片的API (解决问题1：图鉴空白)
@app.get("/postcards", response_class=JSONResponse)
async def get_all_postcards():
    try:
        # 从Supabase查询postcards表，并按创建时间倒序排序
        response = supabase.table("postcards").select("*").order("created_at", desc=True).execute()
        
        # 检查查询数据
        if not hasattr(response, 'data'):
            raise Exception("从数据库获取数据失败，响应格式不正确。")
        
        return JSONResponse(content={"success": True, "data": response.data})
    except Exception as e:
        print(f"获取所有明信片时出错: {e}")
        return JSONResponse(content={"success": False, "error": f"获取图鉴数据失败: {e}"}, status_code=500)

@app.post("/generate", response_class=JSONResponse)
async def generate_emoji(request: Request, emotion: str = Form(...), text: str = Form(...)):
    # 1. 从LLM服务获取创意Prompt和所有文本数据
    print(f"收到请求: 情绪='{emotion}', 文字='{text}'")
    try:
        llm_result = await llm_service.generate_creative_prompt(emotion, text)
        if not llm_result:
            return JSONResponse(content={"error": "从LLM获取创意内容失败。"}, status_code=500)

        positive_prompt = llm_result.get("positive_prompt")
        pose_keyword = llm_result.get("controlnet_pose_keyword")
        
        if not all([positive_prompt, pose_keyword]):
            return JSONResponse(content={"error": "LLM返回的数据不完整，缺少prompt或姿势关键字。"}, status_code=500)

    except Exception as e:
        print(f"调用LLM服务时出错: {e}")
        return JSONResponse(content={"error": f"调用LLM服务时出错: {e}"}, status_code=500)


    # 2. 找到对应的姿势图片并生成基础图片
    pose_image_path = f"data/controlnet_poses/{pose_keyword}.png"
    try:
        generated_image_bytes = await image_generator.generate_image_from_prompt(
            prompt=positive_prompt,
            pose_image_path=pose_image_path
        )
    except FileNotFoundError:
        error_msg = f"姿势文件未找到: {pose_image_path}。请确认'{pose_keyword}'是一个有效的姿势关键字。"
        print(error_msg)
        return JSONResponse(content={"error": error_msg}, status_code=404)
    except Exception as e:
        print(f"生成图片时出错: {e}")
        return JSONResponse(content={"error": f"生成图片失败: {e}"}, status_code=500)

    # 3. 将用户原始文字添加到图片上
    final_image_bytes = post_processor.add_text_to_image(generated_image_bytes, text)

    # --- 上传到Supabase并保存记录 ---
    try:
        # 4. 上传图片到Supabase Storage
        file_name = f"postcards/{uuid.uuid4()}.png"
        supabase.storage.from_("postcards").upload(
            file=final_image_bytes,
            path=file_name,
            file_options={"content-type": "image/png", "upsert": "false"}
        )

        # 5. 获取上传后图片的公共URL
        image_public_url = supabase.storage.from_("postcards").get_public_url(file_name)

        # 6. 将所有信息存入Supabase数据库
        postcard_data = {
            "image_url": image_public_url,
            "location_name": llm_result.get("location_name"),
            "travelogue_snippet": llm_result.get("travelogue_snippet"),
            "map_coordinates": llm_result.get("map_coordinates"),
            "user_prompt": text,
            "emotion": emotion
        }
        db_response = supabase.table("postcards").insert(postcard_data).execute()
        
        if not db_response.data:
             raise Exception(f"数据库插入失败: {db_response.error.message if db_response.error else '未知错误'}")

        # 7. 将新创建的明信片数据返回给前端
        newly_created_postcard = db_response.data[0]
        return JSONResponse(content={"success": True, "data": newly_created_postcard})

    except Exception as e:
        print(f"上传或写入Supabase时出错: {e}")
        if 'file_name' in locals():
            supabase.storage.from_("postcards").remove([file_name])
            print(f"已尝试清理上传失败的文件: {file_name}")
        return JSONResponse(content={"error": f"保存旅行日记时出错，请稍后重试。"}, status_code=500)