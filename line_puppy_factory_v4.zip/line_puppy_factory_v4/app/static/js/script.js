document.addEventListener('DOMContentLoaded', () => {
    // ✅ 优化: 不再需要从前端直接连接Supabase，相关的初始化代码已被注释。
    /*
    const SUPABASE_URL = 'https://gejazcixowcforgmmvme.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdlamF6Y2l4b3djZm9yZ21tdm1lIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE1MDk4NTAsImV4cCI6MjA2NzA4NTg1MH0.enP8wYLTP7WsqV-OTjTcMmUKyt-xfXj6IBjMSOkoA0Q';

    if (!window.supabase) {
        console.error("Supabase JS 库未加载。请确保已在HTML中正确引入。");
        alert("应用配置错误，无法连接到数据库。");
        return;
    }
    const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    */

    // --- 视图元素 ---
    const mainView = document.getElementById('main-view');
    const loadingView = document.getElementById('loading-view');
    const packageView = document.getElementById('package-view');
    const postcardView = document.getElementById('postcard-view');
    const atlasView = document.getElementById('atlas-view');

    // --- 主界面元素 ---
    const form = document.getElementById('emoji-form');
    const emotionInput = document.getElementById('emotion-input');
    const generateBtn = document.getElementById('generate-btn');
    const locations = document.querySelectorAll('.location-dot');

    // --- 明信片视图元素 ---
    const surprisePackage = document.getElementById('surprise-package');
    const postcardImage = document.getElementById('postcard-image');
    const postcardCoords = document.getElementById('postcard-coords');
    const postcardLocation = document.getElementById('postcard-location');
    const postcardLog = document.getElementById('postcard-log');
    const restartButton = document.getElementById('restart-button');

    // --- 旅行图鉴元素 ---
    const atlasButton = document.getElementById('atlas-button');
    const atlasCloseButton = document.getElementById('atlas-close-button');
    const atlasGrid = document.getElementById('atlas-grid');

    // --- 全局状态 ---
    let currentPostcardData = null;
    let lastActiveView = mainView; 

    // --- 视图切换函数 ---
    const switchView = (viewToShow) => {
        // 寻找当前显示的视图 (除了图鉴本身) 并记录它
        document.querySelectorAll('.view:not(.hidden)').forEach(activeView => {
            if (activeView.id !== 'atlas-view') {
                 // ✅ 修复(解决问题3): 将 'lastActiveVew' 的拼写错误修正为 'lastActiveView'
                lastActiveView = activeView;
            }
        });
        
        [mainView, loadingView, packageView, postcardView, atlasView].forEach(view => {
            view.classList.toggle('hidden', view !== viewToShow);
        });
    };

    // --- 地图地点选择逻辑 ---
    locations.forEach(loc => {
        loc.addEventListener('click', () => {
            locations.forEach(l => l.classList.remove('selected'));
            loc.classList.add('selected');
            emotionInput.value = loc.dataset.emotion;
        });
    });

    // --- 表单提交逻辑 ---
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!emotionInput.value) {
            alert('请先在地图上选择一个目的地！');
            return;
        }

        switchView(loadingView);
        generateBtn.disabled = true;

        try {
            const response = await fetch('/generate', {
                method: 'POST',
                body: new FormData(form),
            });
            
            const result = await response.json();

            if (!response.ok || !result.success) {
                throw new Error(result.error || '生成明信片时发生未知错误。');
            }
            
            currentPostcardData = result.data; 
            postcardImage.src = currentPostcardData.image_url; 
            
            switchView(packageView);

        } catch (error) {
            console.error('生成失败:', error);
            alert(`生成失败: ${error.message}`);
            switchView(mainView);
        } finally {
            generateBtn.disabled = false;
        }
    });

    // --- 包裹点击逻辑 ---
    surprisePackage.addEventListener('click', () => {
        if (currentPostcardData) {
            postcardLocation.textContent = currentPostcardData.location_name;
            postcardLog.textContent = currentPostcardData.travelogue_snippet;
            postcardCoords.textContent = currentPostcardData.map_coordinates;
        }

        surprisePackage.classList.add('package-opening');
        setTimeout(() => {
            switchView(postcardView);
            surprisePackage.classList.remove('package-opening');
        }, 500);
    });

    // --- 重新开始逻辑 ---
    restartButton.addEventListener('click', () => {
        form.reset();
        locations.forEach(l => l.classList.remove('selected'));
        emotionInput.value = '';
        currentPostcardData = null;
        switchView(mainView);
    });

    // --- 旅行图鉴逻辑 ---

    // 新的 renderAtlas 函数，从我们的后端 /postcards 接口获取数据
    const renderAtlas = async () => {
        // ✅ 修复(解决问题2): 移除小狗加载动画，使用更简洁的文字提示，避免UI混淆
        atlasGrid.innerHTML = '<p class="atlas-empty-message">正在加载图鉴...</p>';

        try {
            // ✅ 修复(解决问题1): 从自己的后端API获取数据
            const response = await fetch('/postcards');
            const result = await response.json();

            if (!response.ok || !result.success) {
                throw new Error(result.error || '获取图鉴数据失败。');
            }
            
            const data = result.data;
            atlasGrid.innerHTML = ''; // 清空加载提示

            if (data.length === 0) {
                atlasGrid.innerHTML = '<p class="atlas-empty-message">还没有任何旅行记录，快去创造你的第一张明信片吧！</p>';
            } else {
                data.forEach(postcard => {
                    const img = document.createElement('img');
                    img.src = postcard.image_url;
                    img.alt = postcard.travelogue_snippet || '收藏的明信片';
                    img.title = `在“${postcard.location_name}”的旅行回忆`;
                    atlasGrid.appendChild(img);
                });
            }
        } catch(error) {
            console.error('获取图鉴失败:', error);
            atlasGrid.innerHTML = `<p class="atlas-empty-message">加载图鉴失败: ${error.message}</p>`;
        }
    };

    // 打开图鉴按钮逻辑
    atlasButton.addEventListener('click', (event) => {
        // ✅ 修复(解决问题3): 增加 event.preventDefault() 阻止任何可能的默认行为
        event.preventDefault(); 
        renderAtlas();
        switchView(atlasView);
    });

    // 关闭图鉴按钮逻辑
    atlasCloseButton.addEventListener('click', () => {
        // 这个函数现在可以正常工作了，因为 'lastActiveView' 变量被正确更新了
        switchView(lastActiveView); 
    });
});