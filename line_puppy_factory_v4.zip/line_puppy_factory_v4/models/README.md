# 训练好的模型

当你使用Kohya's GUI等工具训练好你的LoRA模型后，请将最终的模型文件放在这里。

**本应用预期LoRA模型文件名为 `xiantiaogou_style.safetensors`。**