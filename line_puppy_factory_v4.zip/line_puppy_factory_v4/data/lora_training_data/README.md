# LoRA 训练数据
1.  请将你收集的30-70张高质量、背景干净的“线条小狗”图片放在这里。支持 `.png`, `.jpg`, `.jpeg` 格式。
2.  **请确保在项目根目录的 `.env` 文件中设置了你的 Gemini API 密钥。**
3.  在项目根目录运行自动化打标脚本：
    ```bash
    python scripts/automate_tagging.py data/lora_training_data/
    ```
4.  脚本会为每张图片生成一个 `.txt` 标签文件。请抽查它们的准确性。