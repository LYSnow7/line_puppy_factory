# ControlNet 姿势库

请将用于ControlNet的姿势源文件放在这里。这些文件应该是代表不同姿势的简单线条图或轮廓图。

请根据LLM可能使用的关键词来命名它们，例如：

- `lying_flat.png`- `jumping_happy.png`- `sitting_sad.png`- `waving_hello.png`