# scripts/automate_tagging.py
import os
import google.generativeai as genai
from PIL import Image
import argparse
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()
GOOGLE_API_KEY = os.getenv('GEMINI_API_KEY')

# 检查API密钥是否存在
if not GOOGLE_API_KEY:
    print("错误：未找到 GEMINI_API_KEY。请检查你的 .env 文件。")
    exit()

genai.configure(api_key=GOOGLE_API_KEY)
vision_model = genai.GenerativeModel('gemini-1.5-flash-latest')

TAGGER_PROMPT = """
你是一个专业的LoRA数据集图像标注专家。你的任务是为我提供的图片生成精准的、逗号分隔的标签。
请严格遵循以下规则：
1.  必须包含触发词：在所有标签的开头，固定加入 xiantiaogou_style, 1dog。
2.  标签格式：全部使用小写英文，单词之间用下划线 _ 连接，标签之间用逗号和空格 , 分隔。
3.  描述内容：从通用到具体，描述图像的风格、主体、姿势、表情和构图。
4.  忠于事实：只描述图片中确实存在的内容。
"""

def tag_image(image_path):
    if not os.path.exists(image_path):
        print(f"错误: 找不到图片文件 {image_path}")
        return

    print(f"正在使用Gemini分析图片: {image_path}...")
    try:
        img = Image.open(image_path)
        response = vision_model.generate_content([TAGGER_PROMPT, img])
        tags = response.text.strip()
        txt_filename = os.path.splitext(image_path)[0] + '.txt'
        with open(txt_filename, 'w', encoding='utf-8') as f:
            f.write(tags)
        print(f"成功生成标签: {tags}")
        print(f"标签已保存至: {txt_filename}")

    except Exception as e:
        print(f"使用Gemini分析图片时出错: {e}")

def main():
    # 这部分定义了脚本如何接收参数
    parser = argparse.ArgumentParser(description="Automate tagging of images for LoRA training using Gemini.")
    parser.add_argument("image_path", type=str, help="The path to the image file or a directory of images.")
    args = parser.parse_args()

    if os.path.isdir(args.image_path):
        print(f"Processing all supported images in directory: {args.image_path}")
        for filename in os.listdir(args.image_path):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                file_path = os.path.join(args.image_path, filename)
                tag_image(file_path)
    elif os.path.isfile(args.image_path):
        tag_image(args.image_path)
    else:
        print(f"Error: Path does not exist: {args.image_path}")

if __name__ == "__main__":
    main()