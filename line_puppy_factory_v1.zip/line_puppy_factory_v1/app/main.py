import os
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv

from .services import llm_service, image_generator, post_processor

load_dotenv()

app = FastAPI()

app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    # Define locations with names, corresponding emotions, and coordinates for CSS
    locations = [
        {"name":"快乐海滩", "emotion":"开心", "style":"top:25%; left:65%;"},
        {"name":"忧伤山谷", "emotion":"难过", "style":"top:50%; left:20%;"},
        {"name":"愤怒火山", "emotion":"生气", "style":"top:70%; left:80%;"},
        {"name":"空虚废墟", "emotion":"生无可恋", "style":"top:85%; left:40%;"},
        {"name":"沉思森林", "emotion":"思考", "style":"top:15%; left:15%;"},
        {"name":"庆典广场", "emotion":"庆祝", "style":"top:45%; left:50%;"}
    ]
    return templates.TemplateResponse("index.html", {"request":request, "locations":locations})

@app.post("/generate", response_class=Response)
async def generate_emoji(request: Request, emotion: str = Form(...), text: str = Form(...)):
    # 1. 从LLM服务获取创意Prompt
    print(f"收到请求: 情绪='{emotion}', 文字='{text}'")
    llm_result = await llm_service.generate_creative_prompt(emotion, text)
    if not llm_result:
        return Response(content="从LLM获取创意Prompt失败。", status_code=500)

    positive_prompt = llm_result.get("positive_prompt")
    pose_keyword = llm_result.get("controlnet_pose_keyword")
    print(f"LLM 生成的Prompt: {positive_prompt}")
    print(f"LLM 建议的姿势关键词: {pose_keyword}")

    # 2. 找到对应的姿势图片
    pose_image_path = f"data/controlnet_poses/{pose_keyword}.png"

    # 3. 使用Stable Diffusion服务生成基础图片
    try:
        generated_image_bytes = await image_generator.generate_image_from_prompt(
            prompt=positive_prompt,
            pose_image_path=pose_image_path
        )
    except FileNotFoundError as e:
        return Response(content=str(e), status_code=404)
    except Exception as e:
        return Response(content=f"生成图片失败: {e}", status_code=500)

    # 4. 将用户文字添加到图片上
    final_image_bytes = post_processor.add_text_to_image(generated_image_bytes, text)

    # 5. 返回最终的图片
    return Response(content=final_image_bytes, media_type="image/png")