document.addEventListener('DOMContentLoaded', () => {
    // --- 元素获取 ---
    const form = document.getElementById('emoji-form');
    const emotionInput = document.getElementById('emotion-input');
    const generateBtn = document.getElementById('generate-btn');
    const resultContainer = document.getElementById('result-container');
    const loader = document.getElementById('journey-loader');
    const surprisePackage = document.getElementById('surprise-package');
    const postcardImage = document.getElementById('postcard-image');
    const locations = document.querySelectorAll('.location-dot');

    // --- 事件监听：地图地点选择 ---
    locations.forEach(loc => {
        loc.addEventListener('click', () => {
            locations.forEach(l => l.classList.remove('selected'));
            loc.classList.add('selected');
            emotionInput.value = loc.dataset.emotion;
        });
    });

    // --- 事件监听：表单提交 ---
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        if (!emotionInput.value) {
            alert('请先在地图上选择一个目的地！');
            return;
        }

        // 1. 开始加载
        generateBtn.disabled = true;
        generateBtn.textContent = '明信片制作中...';
        resultContainer.classList.remove('hidden');
        postcardImage.classList.add('hidden');
        surprisePackage.classList.add('hidden');
        loader.classList.remove('hidden');

        try {
            const response = await fetch('/generate', {
                method: 'POST',
                body: new FormData(form),
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`生成失败: ${errorText}`);
            }
            
            // 2. 加载成功，准备显示包裹
            const imageBlob = await response.blob();
            const imageUrl = URL.createObjectURL(imageBlob);
            postcardImage.src = imageUrl; // 预加载图片

            loader.classList.add('hidden'); // 隐藏加载动画
            surprisePackage.classList.remove('hidden'); // 显示惊喜包裹

        } catch (error) {
            console.error('错误:', error);
            alert(error.message);
            // 出错时重置UI
            generateBtn.disabled = false;
            generateBtn.textContent = '出发！生成明信片';
            resultContainer.classList.add('hidden');
            loader.classList.add('hidden');
        }
    });

    // --- 新增事件监听：点击惊喜包裹 ---
    surprisePackage.addEventListener('click', () => {
        // 添加打开动画，并在动画结束后显示明信片
        surprisePackage.classList.add('package-opening');

        setTimeout(() => {
            surprisePackage.classList.add('hidden');
            surprisePackage.classList.remove('package-opening'); // 重置动画类
            postcardImage.classList.remove('hidden'); // 显示明信片
            
            // 重置按钮状态
            generateBtn.disabled = false;
            generateBtn.textContent = '再来一次！';
        }, 500); // 动画时长为0.5秒
    }, { once: true }); // { once: true } 确保该事件只触发一次
});