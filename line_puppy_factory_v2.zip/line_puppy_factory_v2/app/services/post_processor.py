# app/services/post_processor.py
from PIL import Image, ImageDraw, ImageFont
import io
import os
import textwrap

def add_text_to_image(image_bytes: bytes, text: str) -> bytes:
    """
    在图片底部直接叠加带有描边的文字。
    此版本支持长文本自动换行，并移除了文字背景。
    """
    try:
        # 1. 打开图片并确保为RGBA模式以支持透明度
        image = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
        width, height = image.size
        draw = ImageDraw.Draw(image)

        # 2. ---核心修改：调整字体大小---
        font_size = 45 # 将字号从 50 调整为 45

        # --- 智能字体查找逻辑 (保持不变) ---
        font = None
        font_paths = [
            'simhei.ttf', 'PingFang.ttc', 'STHeiti Medium.ttc',
            'msyh.ttc', 'simsun.ttc', '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
        ]
        for path in font_paths:
            try:
                font = ImageFont.truetype(path, size=font_size)
                print(f"成功加载字体: {path}")
                break
            except IOError:
                continue
        if font is None:
            print("警告: 找不到任何可用的中文字体，将使用默认字体。")
            try:
                font = ImageFont.truetype(size=font_size)
            except IOError:
                font = ImageFont.load_default()

        # 3. --- 自动换行核心逻辑 ---
        margin = 40
        try:
            char_width = font.getbbox("国")[2]
        except AttributeError:
            char_width = font.getsize("国")[0]
            
        max_chars_per_line = (width - margin * 2) // char_width
        lines = textwrap.wrap(text, width=max_chars_per_line)

        # 4. 计算文字位置
        try:
            line_bbox = draw.textbbox((0, 0), lines[0] if lines else "", font=font)
            line_height = line_bbox[3] - line_bbox[1]
        except AttributeError:
            line_height = draw.textsize(lines[0] if lines else "", font=font)[1]
        
        line_spacing = 15
        total_text_height = len(lines) * line_height + (len(lines) - 1) * line_spacing
        text_block_y_start = height - total_text_height - margin

        # 5. ---核心修改：移除文字背景绘制---
        # 此处原有的 draw.rounded_rectangle(...) 代码块已被移除。

        # 6. 逐行绘制带描边的文字
        current_y = text_block_y_start
        for line in lines:
            try:
                line_bbox = draw.textbbox((0, 0), line, font=font)
                line_width = line_bbox[2] - line_bbox[0]
            except AttributeError:
                line_width = draw.textsize(line, font=font)[0]
            
            line_x = (width - line_width) / 2
            
            # ---核心修改：将文字改为黑色，并添加白色描边---
            draw.text(
                (line_x, current_y),
                line,
                font=font,
                fill="black",          # 文字颜色改为黑色
                stroke_width=2,        # 添加2像素的描边
                stroke_fill="white"    # 描边颜色为白色
            )
            current_y += line_height + line_spacing

        # 7. 保存最终图片
        byte_arr = io.BytesIO()
        image.save(byte_arr, format='PNG')
        return byte_arr.getvalue()

    except Exception as e:
        print(f"图像后处理时出错: {e}")
        return image_bytes

